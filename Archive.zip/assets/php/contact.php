<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

    if (isset($_POST["name"]) && $_POST["name"] != null && isset($_POST["email"]) && $_POST["email"] != null
        && isset($_POST["message"]) && $_POST["message"] != null) {

    
        if (isset($_POST["grecaptcha"]) && !empty($_POST["grecaptcha"])) {

            $verifyCaptcha = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=6LeFSaMZAAAAALkxtJlcQiv995n_EpF7Xb111r-c&response=".$_POST["grecaptcha"]);
            $verifyCaptchaResponse = json_decode($verifyCaptcha);

            if ($verifyCaptchaResponse->success) {
                $mail = new PHPMailer(true);

                try {
                    //Server settings
                    $mail->isSMTP();                                            
                    $mail->Host       = 'premium60.web-hosting.com';                    
                    $mail->SMTPAuth   = true;                                   
                    $mail->Username   = 'form@connermurphy.net';                     
                    $mail->Password   = 'Eu.-3gwjKK3*';                               
                    $mail->SMTPSecure = "ssl";                                  
                    $mail->Port       = 465;                            
        
                    //Recipients
                    $mail->setFrom("form@connermurphy.net", $_POST["name"]);
                    $mail->addAddress('enquiry@connermurphy.net', 'Conner Murphy');     
                    $mail->addReplyTo($_POST["email"], $_POST["name"]);
        
                    $mail->isHTML(false);                                  
                    $mail->Subject = "New Contact Form Enquiry";
                    $mail->Body    = $_POST["message"];
        
                    $mail->send();
                    echo '1';
        
                } catch (Exception $e) {
                    echo $mail->ErrorInfo;
                } 
            } else {
                echo "2";
            }
            
        } else {
            echo "2";
        }
    

    } else {
        header("Location: /");
    }

?>